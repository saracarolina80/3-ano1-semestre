T = [1 1 1/2 1/3 1/4; 0 0 1/2 1/3 1/4; 0 0 0 1/3 1/4; 0 0 0 0 1/4; 0 0 0 0 0]

Tadaptada = [0 1/2 1/3 1/4 0; 0 0 1/3 1/4 0; 0 0 0 1/4 0; 0 0 0 0 0; 1 1/2 1/3 1/4 1];
Q = Tadaptada(1:4, 1:4);
aux = eye(size(Q)) - Q;
F = inv(aux);

%Como a cadeia começa sempre em E, só interessa a coluna relativa ao E
numeroMedioPassos = sum(F(:,4));



T = [1 1 0 1/3 1/4; 0 0 0 1/3 1/4; 0 0 1 1/3 1/4; 0 0 0 0 1/4; 0 0 0 0 0];
Tadaptada = [0 1/3 1/4 0 0; 0 0 1/4 0 0; 0 0 0 0 0; 0 1/3 1/4 1 0; 1 1/3 1/4 0 1];
Q = Tadaptada(1:3, 1:3)
aux = eye(size(Q)) - Q;
F = inv(aux)
R = Tadaptada(4:5, 1:3);
b = R * F;